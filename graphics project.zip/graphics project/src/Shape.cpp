#include "Shape.h"
#if defined(UNICODE) && !defined(_UNICODE)
    #define _UNICODE
#elif defined(_UNICODE) && !defined(UNICODE)
    #define UNICODE
#endif



int Round(double x){
    return (int) x+0.5;
}
//10
void DrawLineParametric(HDC hdc, int x1, int y1, int x2, int y2, COLORREF c){
    int dx=x2-x1, dy=y2-y1;
    double dt= 1.0/max(abs(dx),abs(dy));
    for(double t=0;t<=1;t+=dt){
        int x=Round(x1+t*dx);
        int y=Round(y1+t*dy);
        SetPixel(hdc,x,y,c);
    }
}
//8
void DrawLineDDA(HDC hdc, int x1, int y1, int x2, int y2, COLORREF c){
    int dx=x2-x1,dy=y2-y1;
    if(abs(dy)<=abs(dx)){
        if(x2<x1){
            swap(x1,x2);
            swap(y1,y2);
        }
        double m= (double)dy/dx;
        int x=x1;
        double y=y1;
        SetPixel(hdc,x,y,c);
        while(x<x2){
            x++;
            y+=m;
            SetPixel(hdc,x,Round(y),c);
        }
    }
    else{
        if(y1>y2){
            swap(x1,x2);
            swap(y1,y2);
        }
        double m=(double)dx/dy;
        int y=y1;
        double x=x1;
        SetPixel(hdc,x,y,c);
        while(y<y2){
            y++;
            x+=m;
            SetPixel(hdc,Round(x),y,c);
        }
    }
}
//9
void DrawLineMidPoint(HDC hdc, int x1, int y1, int x2, int y2, COLORREF c){
    int x=x1, y=y1;
    double dx=x2-x1,dy=y2-y1;
    SetPixel(hdc,x,y,c);
    if((dx==0||dy/dx>1)&&dy>0&&dx>=0)
    {
        int d=2*dx-dy,d1=2*dx,d2=2*dx-2*dy;
        while(y!=y2)
        {
            if(d<=0)
            {
                y++;
                d+=d1;
            }
            else
            {
                x++;
                y++;
                d+=d2;
            }
            SetPixel(hdc,x,y,c);
        }
    }
    else if(dy/dx>=0&&dy/dx<=1&&dy>0&&dx>0)
    {
        int d=dx-2*dy,d1=-2*dy,d2=2*dx-2*dy;
        while(x!=x2)
        {
            if(d>0)
            {
                x++;
                d+=d1;
            }
            else
            {
                x++;
                y++;
                d+=d2;
            }
            SetPixel(hdc,x,y,c);
        }
    }
    else if(dy/dx<0&&dy/dx>=-1&&dy<0&&dx>0)
    {
        int d=-dx-2*dy,d1=-2*dy,d2=-2*dx-2*dy;
        while(x!=x2)
        {
            if(d<=0)
            {
                x++;
                d+=d1;
            }
            else
            {
                x++;
                y--;
                d+=d2;
            }
            SetPixel(hdc,x,y,c);
        }
    }
    else if((dx==0||dy/dx<-1)&&dy<0&&dx>=0)
    {
        int d=-2*dx-dy,d1=-2*dx,d2=-2*dx-2*dy;
        while(y!=y2)
        {
            if(d>0)
            {
                y--;
                d+=d1;
            }
            else
            {
                x++;
                y--;
                d+=d2;
            }
            SetPixel(hdc,x,y,c);
        }
    }
    else if((dx==0||dy/dx>1)&&dy<0&&dx<=0)
    {
        int d=-2*dx+dy,d1=-2*dx,d2=-2*dx+2*dy;
        while(y!=y2)
        {
            if(d<=0)
            {
                y--;
                d+=d1;
            }
            else
            {
                x--;
                y--;
                d+=d2;
            }
            SetPixel(hdc,x,y,c);
        }
    }
    else if(dy/dx>=0&&dy/dx<=1&&dy<0&&dx<0)
    {
        int d=-dx+2*dy,d1=2*dy,d2=-2*dx+2*dy;
        while(x!=x2)
        {
            if(d>0)
            {
                x--;
                d+=d1;
            }
            else
            {
                x--;
                y--;
                d+=d2;
            }
            SetPixel(hdc,x,y,c);
        }
    }
    else if(dy/dx<0&&dy/dx>=-1&&dy>0&&dx<0)
    {
        int d=dx+2*dy,d1=2*dy,d2=2*dx+2*dy;
        while(x!=x2)
        {
            if(d<=0)
            {
                x--;
                d+=d1;
            }
            else
            {
                x--;
                y++;
                d+=d2;
            }
            SetPixel(hdc,x,y,c);
        }
    }
    else if((dx==0||dy/dx<-1)&&dy>0&&dx<=0)
    {
        int d=2*dx+dy,d1=2*dx,d2=2*dx+2*dy;
        while(y!=y2)
        {
            if(d>0)
            {
                y++;
                d+=d1;
            }
            else
            {
                x--;
                y++;
                d+=d2;
            }
            SetPixel(hdc,x,y,c);
        }
    }



}



void Draw4points(HDC hdc, int xc, int yc, int x, int y, COLORREF c){
    SetPixel(hdc,xc+x,yc+y,c);
    SetPixel(hdc,xc-x,yc+y,c);
    SetPixel(hdc,xc+x,yc-y,c);
    SetPixel(hdc,xc-x,yc-y,c);
}

void Draw8points(HDC hdc, int xc, int yc, int x, int y, COLORREF c)
{
    SetPixel(hdc,xc+x,yc+y,c);
    SetPixel(hdc,xc-x,yc+y,c);
    SetPixel(hdc,xc+x,yc-y,c);
    SetPixel(hdc,xc-x,yc-y,c);
    SetPixel(hdc,xc+y,yc+x,c);
    SetPixel(hdc,xc+y,yc-x,c);
    SetPixel(hdc,xc-y,yc-x,c);
    SetPixel(hdc,xc-y,yc+x,c);
}
void Draw8points_4th(HDC hdc, int xc, int yc, int x, int y, COLORREF f)
{

    for(int i=xc;i<xc+x;i++)SetPixel(hdc,i,yc+y,f);
    for(int i=xc;i<xc+y;i++)SetPixel(hdc,i,yc+x,f);
}
void Draw8points_3rd(HDC hdc, int xc, int yc, int x, int y, COLORREF f)
{
    for(int i=xc;i>xc-x;i--)SetPixel(hdc,i,yc+y,f);
    for(int i=xc;i>xc-y;i--)SetPixel(hdc,i,yc+x,f);
}
void Draw8points_2nd(HDC hdc, int xc, int yc, int x, int y, COLORREF f)
{
    for(int i=xc;i>xc-x;i--)SetPixel(hdc,i,yc-y,f);
    for(int i=xc;i>xc-y;i--)SetPixel(hdc,i,yc-x,f);
}
void Draw8points_1st(HDC hdc, int xc, int yc, int x, int y, COLORREF f)
{
    for(int i=xc;i<xc+x;i++)SetPixel(hdc,i,yc-y,f);
    for(int i=xc;i<xc+y;i++)SetPixel(hdc,i,yc-x,f);
}

void DrawQCircleMidPoint(HDC hdc, int xc, int yc, int R, COLORREF c,int q){
    int x=0,y=R,d=1-R,d1=3,d2=5-2*R;
    if(q==18)
        Draw8points_1st(hdc, xc, yc, x,y,c);
    else if(q==19)
        Draw8points_2nd(hdc, xc, yc, x,y,c);
    else if (q==20)
        Draw8points_3rd(hdc, xc, yc, x,y,c);
    else if(q==21)
            Draw8points_4th(hdc, xc, yc, x,y,c);
    while(x<y){
        if(d<=0){
            d+=d1;
            d2+=2;
        }
        else{
            d+=d2;
            d2+=4;
            y--;
        }
        x++;
        d1+=2;
        if(q==18)
            Draw8points_1st(hdc, xc, yc, x,y,c);
        else if(q==19)
            Draw8points_2nd(hdc, xc, yc, x,y,c);
        else if (q==20)
            Draw8points_3rd(hdc, xc, yc, x,y,c);
        else if(q==21)
            Draw8points_4th(hdc, xc, yc, x,y,c);
    }
}

//14
void DrawCirclePolar(HDC hdc, int xc, int yc, int R, COLORREF c){
    double dtheta=1.0/R;
    for(double theta=0;theta<6.28;theta+=dtheta){
        int x= Round(xc+R*cos(theta));
        int y=Round(yc+R*sin(theta));
        SetPixel(hdc,x,y,c);
    }
}
//15
void DrawCirclePolarIterative(HDC hdc, int xc, int yc, int R, COLORREF col){
    double dt=1.0/R;
    double c= cos(dt), s=sin(dt);
    double x=R,y=0;
    Draw8points(hdc,xc,yc,x,y,col);
    while(x>y){
        double x1= x*c-y*s;
        y=x*s+y*c;
        x=x1;
        Draw8points(hdc,xc,yc,Round(x),Round(y),col);
    }
}
//13
void DrawCircleCartesian(HDC hdc, int xc, int yc, int R, COLORREF col){
    int x=0, y=R;
    Draw8points(hdc,xc,yc,x,y,col);
    while(x<y){
        x++;
        y=sqrt(R*R-x*x);
        Draw8points(hdc,xc,yc,x,y,col);
    }
}
//12
void DrawCircleMidPoint(HDC hdc, int xc, int yc, int R, COLORREF c){
    int x=0,y=R,d=1-R;
    Draw8points(hdc, xc, yc, x,y,c);
    while(x<y){
        if(d<0){
            d+=2*x+3;
            x++;
        }
        else{
            d+=2*(x-y)+5;
            x++;
            y--;
        }
        Draw8points(hdc,xc,yc,x,y,c);
    }
}
//11
void DrawCircleMidPointModification(HDC hdc, int xc, int yc, int R, COLORREF c){
    int x=0,y=R,d=1-R,d1=3,d2=5-2*R;
    Draw8points(hdc, xc, yc, x,y,c);
    while(x<y){
        if(d<=0){
            d+=d1;
            d2+=2;
        }
        else{
            d+=d2;
            d2+=4;
            y--;
        }
        x++;
        d1+=2;
        Draw8points(hdc,xc,yc,x,y,c);
    }
}
//16
void DrawEllipsePolar(HDC hdc, int xc, int yc, int A,int B, COLORREF c){
    double dtheta=1.0/max(A,B);
    for(double theta=0;theta<6.28;theta+=dtheta){
        int x= Round(xc+A*cos(theta));
        int y=Round(yc+B*sin(theta));
        SetPixel(hdc,x,y,c);
    }
}
//17
void DrawEllipsePolarIterative(HDC hdc, int xc, int yc, int A,int B, COLORREF col){
    double dtheta=1.0/max(A,B);
    double cd= cos(dtheta), sd=sin(dtheta);
    double x=xc+A, y= yc;
    double ct= (x-xc)/A;
    double st=(y-yc)/B;
    for(double theta=0;theta<6.28;theta+=dtheta){
        SetPixel(hdc,Round(x),Round(y),col);
        x= x*cd-st*A*sd;
        y= y*cd+ct*B*sd;
        ct= (x-xc)/A;
        st=(y-yc)/B;
        }
}

double dy_dx(int x,double A,double B)
{
    int y=B*sqrt(1-(pow(x,2)/pow(A,2)));
    return (-x*pow(B,2))/(y*pow(A,2));
}
//22
void DrawEllipseDirectU(HDC hdc, int xc, int yc, int A,int B, COLORREF col){
    int x=0,y=B;
    Draw4points(hdc,xc,yc,x,y,col);
    while(x!=A && y!=0)
    {
        if(dy_dx(x,A,B)<=1)
        {
            x++;
            y=(B*sqrt(1-(pow(x,2)/pow(A,2))));
            Draw4points(hdc,xc,yc,x,y,col);
        }
    }
    x=A, y=0;
    Draw4points(hdc,xc,yc,x,y,col);
    while((y!=B && x!=0))
    {
        if((dy_dx(x,B,A)<1))
        {
            y++;
            x=(A*sqrt(1-(pow(y,2)/pow(B,2))));
            Draw4points(hdc,xc,yc,x,y,col);
        }
    }
}





Line::Line(int x1,int y1,int x2,int y2,COLORREF c,int dA)
{
    this->x1=x1;
    this->y1=y1;
    this->x2=x2;
    this->y2=y2;
    this->c=c;
    this->dA=dA;
}
void Line::draw(HDC hdc)
{
    if(this->dA==8)
        DrawLineDDA(hdc,this->x1,this->y1,this->x2,this->y2,this->c);
    else if(this->dA==9)
        DrawLineMidPoint(hdc,this->x1,this->y1,this->x2,this->y2,this->c);
    else if(this->dA==10)
        DrawLineParametric(hdc,this->x1,this->y1,this->x2,this->y2,this->c);

}
Circle::Circle(int x1,int y1,int x2,int y2,COLORREF c,int dA)
{
    this->x1=x1;
    this->y1=y1;
    this->x2=x2;
    this->y2=y2;
    this->c=c;
    this->dA=dA;
}
void Circle::draw(HDC hdc)
{
    int r= sqrt(pow(this->x2 - this->x1,2)+pow(this->y2 - this->y1,2));
    if(this->dA==14)
        DrawCirclePolar(hdc,this->x1,this->y1,r,this->c);
    else if(this->dA==15)
        DrawCirclePolarIterative(hdc,this->x1,this->y1,r,this->c);
    else if(this->dA==13)
        DrawCircleCartesian(hdc,this->x1,this->y1,r,this->c);
    else if(this->dA==12)
        DrawCircleMidPoint(hdc,this->x1,this->y1,r,this->c) ;
    else if(this->dA==11)
        DrawCircleMidPointModification(hdc,this->x1,this->y1,r,this->c);
}
Ellipsee::Ellipsee(int x1,int y1,int x2,int y2,int x3,int y3,COLORREF c,int dA)
{
    this->x1=x1;
    this->y1=y1;
    this->x2=x2;
    this->y2=y2;
    this->x3=x3;
    this->y3=y3;
    this->c=c;
    this->dA=dA;
}
void Ellipsee::draw(HDC hdc)
{
    int A= sqrt(pow(this->x2 - this->x1,2)+pow(this->y2 - this->y1,2));
    int B= sqrt(pow(this->x3 - this->x1,2)+pow(this->y3 - this->y1,2));
    if(this->dA==16)
        DrawEllipsePolar(hdc,x1,y1,A,B,this->c);
    else if(this->dA==17)
        DrawEllipsePolarIterative(hdc,x1,y1,A,B,this->c);
    else if(this->dA==22)
        DrawEllipseDirectU(hdc,x1,y1,A,B,this->c);
}
QuarterFilledCircle::QuarterFilledCircle(int x1,int y1,int x2,int y2,COLORREF c,int dA)
{
    this->x1=x1;
    this->y1=y1;
    this->x2=x2;
    this->y2=y2;
    this->c=c;
    this->dA=dA;
}
void QuarterFilledCircle::draw(HDC hdc)
{
    int r= sqrt(pow(this->x2 - this->x1,2)+pow(this->y2 - this->y1,2));
    DrawQCircleMidPoint(hdc,this->x1,this->y1,r,this->c,this->dA);
}
Shape::~Shape()
{
    //dtor
}

void Shapevector::addshape (Shape* shape)
{
    this->shapes.push_back(shape);
}
void Shapevector::drawShapes (HDC hdc)
{
    for(unsigned int i=0;i<shapes.size();i++)
    {
        shapes[i]->draw(hdc);
    }
}
void Shapevector::clearshapes()
{
    for(unsigned int i=0;i<shapes.size();i++)
    {
        delete shapes[i];
    }
    shapes.clear();
}
void Shapevector::saveshapes(string path)
{
    ofstream save (path);
    {
        for(unsigned int i =0 ;i<this->shapes.size();i++)
        {
            save<<shapes[i]->dA<<"\t"<<shapes[i]->x1<<"\t"<<shapes[i]->y1<<"\t"<<shapes[i]->x2<<"\t"<<shapes[i]->y2<<"\t"<<shapes[i]->c<<endl;
        }
    }
}
void Shapevector::loadshapes(string path)
{
    this->clearshapes();
    ifstream load (path);
    while(!load.eof())
        {
            int dA,x1,y1,x2,y2;
            COLORREF color;
            load>>dA>>x1>>y1>>x2>>y2>>color;
            if(dA>=8&&dA<=10)
            {
                Shape* nline=new Line(x1,y1,x2,y2,color,dA);
                this->addshape(nline);
            }
            else if(dA>=11&&dA<=15)
            {
                Shape* ncircle=new Circle(x1,y1,x2,y2,color,dA);
                this->addshape(ncircle);

            }
            else if(dA==16||dA==17)
            {
                Shape* nellipsee=new Ellipsee(x1+(x2-x1)/2,y1+(y2-y1)/2,x1,y1+(y2-y1)/2,x1+(x2-x1)/2,y1,color,dA);
                this->addshape(nellipsee);
            }
            else if(dA>=18&&dA<=21)
            {
                    Shape* nfcircle=new QuarterFilledCircle(x1,y1,x2,y2,color,dA);
                    this->addshape(nfcircle);
            }
        }
}
